package org.example;

public enum Mode {
    OFFLINE,
    ONLINE,
    UNKNOWN
}
